package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class HomePageElements {

    WebDriver driver;

    public HomePageElements(WebDriver driver) {
        this.driver = driver;
    }

    public WebElement acceptCookies() {
        return driver.findElement(By.cssSelector("button#onetrust-accept-btn-handler"));
    }

    public By findButtonByText(String text) {
        return By.xpath("//div[@class='caption']/*[text()= \"" + text + "\"]");
    }

    public WebElement homePageTab(String text) {
        return driver.findElement(By.xpath("//*[text()='"+ text +"']"));
    }

    public WebElement findTabDropDownButtonByText(String text) {
        return driver.findElement(By.xpath("//div[text()='"+text+"']"));
    }

    public By findDropDownPageButton(String text) {
        return By.xpath("//div[@class='tab-pane fade in active']//div[text()=\"" + text + "\"]");
    }

}
