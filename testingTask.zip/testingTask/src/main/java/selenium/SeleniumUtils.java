package selenium;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class SeleniumUtils {

    static int DURATION = 15;

    public static WebElement waitForMessage(WebDriver driver, WebElement webElement) {
        WebDriverWait explicitWaitByElement = new WebDriverWait(driver, Duration.ofSeconds(DURATION));
        explicitWaitByElement.until(ExpectedConditions.visibilityOf(webElement));
        return webElement;
    }

    public static WebElement waitVisibilityOf(WebDriver driver, WebElement webElement) {
        WebDriverWait explicitWaitByElement = new WebDriverWait(driver, Duration.ofSeconds(DURATION));
        explicitWaitByElement.until(ExpectedConditions.visibilityOf(webElement));
        return webElement;

    }
}